<template>
    <div class="individuationPage" v-if="showOneComponent">
        <div class="individuationPageClose"><el-button><i class="el-icon-close"
                    @click="closeOneIndividuation()"></i></el-button></div>
        <div class="Interval">
            <div class="chunk"></div>
            <div class="topline"></div>
            <div class="chunk"></div>
        </div>
        <div class="individuationPageTitle">
            <div class="picture"></div>
            <p class="title">个性化生成:{{ individuationResult.onePersonName }}</p>
        </div>
        <div class="individuationPageContent">
            <div class="bombGradeTable">
                <el-table :data="totalTableData"
                    stripe
                    height="100%"
                    style="width: 100%">
                    <el-table-column prop="round" label="标准"></el-table-column>
                    <el-table-column prop="totalBullets" label="实时"></el-table-column>
                    <el-table-column prop="totalScore" label="评估"></el-table-column>
                    <el-table-column prop="averageScore" label="建议"></el-table-column>
                </el-table>
            </div>
            <div if="showPersonAction" class="personAnalyse">
                <div class="personAnalyseVideo">
                    <liveStream :myVideoId="myTestVideo3" :videoUrl="personVideo" :componentWidth="personComponentWidth">
                    </liveStream>
                </div>
                <div class="personAnalyseChart">
                    <radarChart></radarChart>
                </div>
            </div>
        </div>
        <div class="Interval">
            <div class="chunk"></div>
            <div class="bottomline"></div>
            <div class="chunk"></div>
        </div>
        <div class="solutionVideoCover" v-if="showSolutionVideo"></div>
        <div class="solutionVideoStyle" v-if="showSolutionVideo">
            <div class="solutionVideoContent">
                <liveStream :myVideoId="myTestVideoSolution" :videoUrl="solutionVideo" :componentWidth="solutionVideoWidth">
                </liveStream>
            </div>
            <el-button><i class="el-icon-close" @click="closeSolutionVideo()"></i></el-button>
        </div>
    </div>
</template>
    
    
    
<script lang="js">

import radarChart from '../../../../../components/D2RadarChart/indev.vue'
import Bus from '../../../../EventBus/eventBus.js'
import request from '../../../../../utils/request.js'
import liveStream from '../../../../../components/liveStream/index.vue'
export default {
    name: 'shootIndividuation',
    props: {
    },
    data() {
        return {
            showPersonAction: false,
            solutionVideoWidth: "300px",
            myTestVideoSolution: 'oneIndividuationSolutionVideo',
            solutionVideo: "",
            showSolutionVideo: false,
            videoDomainName: "http://10.112.147.7:7878",//"http://10.109.252.160:8000",//
            personComponentWidth: "500px",
            group_id: -1,
            nowPersonId: -1,
            actionIdValue: 5,
            showOneComponent: false,
            individuationResult: {},
            myTestVideo3: 'oneIndividuationVideo',
            personVideo: '',
            defaultIndividuationInformation: {
                onePersonName: "",
                context: [{
                    id: 1,
                    key: 'action',
                    title: '姿态结果与分析',
                    content: [],
                    solution: [],
                },
                {
                    id: 2,
                    key: 'distance',
                    title: '心理结果与分析',
                    content: [],
                    solution: [],
                },]
            },
            totalTableData: [{
                round: "肘部高于肩部",
                totalBullets: "肘部低于肩部",
                totalScore: "上抬臂时未到位、翻肩过早",
                averageScore: "利用标杆进行定位训练，固化肘部高于肩部动作，形成肌肉记忆，1节课训练4组，每组50次。",
            },{
                round: "大臂与小臂夹角为90°-120°",
                totalBullets: "大臂与小臂夹角为80",
                totalScore: "转体过慢造成折小臂，导致小臂里合",
                averageScore: "利用实心球来强化旋转核心力。1节课训练4组，每组10次。",
            },{
                round: "出手角度为45°",
                totalBullets: "出手角度为35°",
                totalScore: "<45°：出手过晚，未能将弹及时投出\n>45°：出手过早，未能将弹及时投出",
                averageScore: "利用标杆反复练习，动作定型，1节课训练4组，每组50次。",
            },{
                round: "反弓角度为8°-25°",
                totalBullets: "-",
                totalScore: "无法控制腰椎，背部未绷紧",
                averageScore: "利用弹力带来练习反弓技术。1节课训练4组，每组15次。",
            },{
                round: "出手速度为33m/s",
                totalBullets: "-",
                totalScore: "小臂挥动过慢，导致初速度达不到",
                averageScore: "利用投掷垒球来提高挥臂速度和出手速度。1节课训练10组，每组5次",
            },{
                round: "肩部不发力",
                totalBullets: "肩部位置前移",
                totalScore: "肩关肌的灵活性和协调性达不到",
                averageScore: "利用挥竹条来训练鞭打技术，体会鞭打时的快与狠劲，找准抽打发力的感觉。1节课训练4组，每组30次。\n利用杠铃片（哑铃）挥臂来增加肩关肌的灵活性和协调性，提高投远专项力量。",
            }]
        }
    },
    components: {
        radarChart,
        liveStream,
    },
    mounted() {
    },
    methods: {
        closeSolutionVideo() {
            this.showSolutionVideo = false;
        },
        closeOneIndividuation() {
            this.showOneComponent = false;
        },
        async openOneVideo() {
            const resVideo = await request.get('/getVideo', {
                params: {
                    group_id: this.group_id,
                    person_id: this.nowPersonId,
                    action_id: this.actionIdValue,
                }
            })
            console.log("单人", resVideo)
            this.personVideo = this.videoDomainName + resVideo.data;
            //console.log("阶段视频的路径名：", this.personVideo);

            this.$nextTick(() => {
                this.showPersonAction = true;
            });
        },
        async playSolutionVideo(text, videoUrl) {
            //console.log(text, videoUrl)
            if (videoUrl.length === 0) {
                return;
            }
            this.solutionVideo = this.videoDomainName + videoUrl;
            //console.log("个人动作建议：",this.solutionVideo)
            this.showSolutionVideo = true;
        }
    },
    created() {
        Bus.$on("bombOneIndividuationInformation", (data) => {
            //console.log("接收数据bombOneIndividuationInformation:", data);
            this.group_id = data.group_id;
            this.nowPersonId = data.nowPersonId;
            this.showOneComponent = data.showBoolean;
            this.personVideo = data.personVideo;
            // this.openOneVideo();
            this.individuationResult = data.context !== undefined ? data.context : this.defaultIndividuationInformation;
        });
    }
}
</script>
    
<style lang="scss" scoped>
@import './index.scss';
</style>