<template>
    <div class="individuationPage" v-if="showComponent">
        <el-button><i class="el-icon-close" @click="closeIndividuation()"></i></el-button>
        <div class="Interval">
            <div class="chunk"></div>
            <div class="topline"></div>
            <div class="chunk"></div>
        </div>
        <div class="individuationPageTitle">
            <div class="picture"></div>
            <p class="title">个性化生成</p>
            <el-dropdown class="groupDropdown" trigger="click">
                <el-button class="groupDropdownButton" type="primary" @click.native="selectGroup()">{{
                    nowGroupLaber }}
                    <i class="el-icon-arrow-down"></i></el-button>
                <el-dropdown-menu class="groupDropdownMenu" slot="dropdown">
                    <div v-for="i in groupCount" :key="i">
                        <el-dropdown-item class="groupDropdownMenuItem" @mouseout="hiddenGroup()"
                            @click.native="chooseGroup(i)">第{{ i
                            }}组</el-dropdown-item>
                    </div>
                </el-dropdown-menu>
            </el-dropdown>
        </div>
        <div class="individuationPageContent">
            <div class="individuationPageContentInfo" v-for="(individuationResult, person_index) in individuationResultList"
                :key="individuationResult.id">
                <!-- <div class="onePersonName">{{ individuationResult.onePersonName }}</div> -->
                <div class="infoItem" v-for="(item, index) in individuationResult.context" :key="item.id">
                    <div class="infoItemTiteAndName" v-if="index === 0">
                        <div class="infoItemTitle">{{ item.title }}</div>
                        <el-button class="infoItemName" type="primary" @click="openOneIndividuationPage(person_index)">{{
                            individuationResult.onePersonName }}</el-button>
                    </div>
                    <div v-else class="infoItemTitle">{{ item.title }}</div>
                    <div v-for="item_content in item.content" :key="item_content.id"
                        :class="parseInt(item_content.state) === 0 ? 'infoItemContentCorrect' : 'infoItemContentError'">{{
                            item_content.text }}</div>
                    <div class="infoItemSolutionTitle" v-if="item.solution.length !== 0"><!--如果item.solution不为空-->
                        <p class="infoItemSolutionTitle">建议方案:</p>
                        <div v-for="item_content in item.solution" :key="item_content.id" class="infoItemSolution">{{
                            item_content.text }}</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="Interval">
            <div class="chunk"></div>
            <div class="bottomline"></div>
            <div class="chunk"></div>
        </div>
    </div>
</template>
    
    
    
<script lang="js">

import Bus from '../../../../EventBus/eventBus.js'
import request from '../../../../../utils/request.js'

export default {
    name: 'shootIndividuation',
    props: {
        // showIndividuation: {
        //     type: Boolean,
        //     default: false,
        // },
    },
    data() {
        return {
            groupCount: [],
            nowGroupLaber: "第1组",
            videoDomainName: "http://10.112.147.7:7878",//"http://10.109.252.160:8000",//
            actionIdValue: 5,
            findGroupId: [-1, -1, -1, -1, -1, -1],
            findPersonId: [0, 1, 2, 0, 1, 2],
            nowGroupId: -1,
            nowPersonId: -1,
            showComponent: false,
            individuationResultList: [],
        }
    },
    components: {

    },
    mounted() {
    },
    methods: {
        closeIndividuation() {
            this.nowGroupLaber = "第1组";
            this.showComponent = false;
            this.$emit("closeIndividuationFun", this.showComponent);
        },
        async openOneIndividuationPage(index) {
            const resVideo = await request.get('/getVideo', {
                params: {
                    group_id: this.findGroupId[index],
                    person_id: this.findPersonId[index],
                    action_id: this.actionIdValue,
                }
            });
            Bus.$emit("bombOneIndividuationInformation", {
                group_id: this.findGroupId[index],
                nowPersonId: this.findPersonId[index],
                showBoolean: true,
                context: this.individuationResultList[index],
                personVideo: this.videoDomainName + resVideo.data,
            });
            this.$emit("openOneIndividuationFun", true);
        },
        async getIndividuationInformation() {
            this.individuationResultList = [];
            let selectGroupId = this.nowGroupId;
            this.findGroupId = [];
            let findPersonName = [];
            let findPersonIdValue = [];
            let findPhyPersonId = [];
            try {
                const resPersonList = await request.get("/person/get", {
                    params: {
                        page_num: 1,
                        page_size: 3,
                        search_type: 'group_id',
                        search_value: selectGroupId.toString(),
                    }
                })
                for (let i = 0; i < resPersonList.data.data.length; i++) {
                    this.findGroupId.push(selectGroupId)
                    findPhyPersonId.push(resPersonList.data.data[i].person_id);
                    findPersonName.push(resPersonList.data.data[i].person_name)
                    findPersonIdValue.push(i)
                }
                for (let j = 0; j < findPersonIdValue.length; j++) {
                    this.individuationResultList[j] = {
                        onePersonName: findPersonName[j],
                        id: "person_id" + j,
                        context: [
                            {
                                id: 1,
                                key: 'action',
                                title: '姿态结果与分析',
                                content: [],
                                solution: [],
                            },
                            {
                                id: 2,
                                key: 'distance',
                                title: '心理结果与分析',
                                content: [],
                                solution: [],
                            }
                        ]
                    };
                    const res = await request.get('/getAdvice', {
                        params: {
                            group_id: this.findGroupId[j],
                            person_id: findPersonIdValue[j],
                        }
                    });
                    for (let i = 0; res.data.result != undefined && i < res.data.result.length; i++) {
                        if (res.data.result[i].key === 'action') {
                            let nowIndex = 0;
                            for (let z = 0; z < res.data.result[i].solution.length; z++) {
                                if (res.data.result[i].solution[z].length !== 0)
                                    this.individuationResultList[j].context[0].solution[nowIndex] = { id: "action_solution_id" + z, videoUrl: res.data.result[i].video_url[z], text: (res.data.result[i].solution[z].length !== 0 ? (++nowIndex) + "、" : '') + res.data.result[i].solution[z] }
                            }
                            nowIndex = 0;
                            for (let z = 0; z < res.data.result[i].value.length; z++) {
                                this.individuationResultList[j].context[0].content[z] = { id: "action_content_id" + z, state: res.data.result[i].state[z], text: (res.data.result[i].value[z].length !== 0 ? (++nowIndex) + "、" : '') + res.data.result[i].value[z] }
                            }
                            break;
                        }
                    }
                    if (findPhyPersonId[j] !== undefined) {
                        const resPhy = await request.get('/get_phy', {
                            params: {
                                group_id: this.findGroupId[j],
                                person_id: findPhyPersonId[j],
                                time_interval: 10,
                            }
                        });

                        if (resPhy.data.data.eval_br_desc) {
                            this.individuationResultList[j].context[1].content[0] = { id: "distance_id_0_" + Math.random(), state: 0, text: (resPhy.data.data.eval_br_desc.length !== 0 ? "1、" + resPhy.data.data.eval_br_desc : "") + "（呼吸）" }
                            // this.individuationResultList[j].context[1].content[1] = { id: "distance_id_1_" + Math.random(), state: 0, text: (resPhy.data.data.eval_hr_desc.length !== 0 ? "2、" + resPhy.data.data.eval_hr_desc : "") + "（心跳）" }
                        }
                        if (resPhy.data.data.eval_hr_desc) {
                            // this.individuationResultList[j].context[1].content[0] = { id: "distance_id_0_" + Math.random(), state: 0, text: (resPhy.data.data.eval_br_desc.length !== 0 ? "1、" + resPhy.data.data.eval_br_desc : "") + "（呼吸）" }
                            this.individuationResultList[j].context[1].content[1] = { id: "distance_id_1_" + Math.random(), state: 0, text: (resPhy.data.data.eval_hr_desc.length !== 0 ? "2、" + resPhy.data.data.eval_hr_desc : "") + "（心跳）" }
                        }
                    }
                }
                this.showComponent = false;
            }
            catch (error) {
                console.log(error);
            }
            this.$nextTick(() => {
                this.showComponent = true;
            });
        },
        async selectGroup() {
            // this.groupCount = [1,2,3,4];
            try {
                const res = await request.get('/get_group_list', {
                    params: {
                    }
                });
                this.groupCount = res.data.data["group_list"];
            }
            catch (error) {
                console.log(error);
            }
            if (this.groupCount.length == 0) {
                alert("当前没有分组信息！");
            }
        },
        async chooseGroup(i) {
            this.nowGroupId = i;
            this.nowGroupLaber = "第" + i + "组";
            this.getIndividuationInformation()
        },
    },
    created() {
        Bus.$on("bombIndividuationGroupAndPerson", (data) => {
            this.nowGroupId = data.groupId;
            this.getIndividuationInformation();
        });
    },
    beforeDestroy() {
        Bus.$off('bombOneIndividuationInformation');
        Bus.$off('openOneIndividuationFun');
    }
}
</script>
    
<style lang="scss" scoped>
@import './index.scss';
</style>