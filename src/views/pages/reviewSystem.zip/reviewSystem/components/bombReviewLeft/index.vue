<template>
  <div class="ContainerLeft">
    <div class="ContainerLeftStandAction">
      <div class="Interval">
        <div class="chunk"></div>
        <div class="line"></div>
        <div class="chunk"></div>
      </div>
      <div class="ContainerLeftStandActionContent">
        <div class="ContainerLeftStandActionContentTitle">
          <div class="picture"></div>
          <p class="title">标准动作</p>
        </div>
        <!-- 存放标准动作; -->
        <div class="ContainerLeftStandActionContentValue">
          <liveStream v-if="WidthHandleLoad" :myVideoId="myTestVideo1" :videoUrl="standardVideoUrl"
            :componentWidth="standardComponentWidth">
          </liveStream>
        </div>
      </div>
      <div class="Interval">
        <div class="chunk"></div>
        <div class="line"></div>
        <div class="chunk"></div>
      </div>
    </div>
    <div class="ContainerLeftSegAction">
      <div class="Interval">
        <div class="chunk"></div>
        <div class="line"></div>
        <div class="chunk"></div>
      </div>
      <div class="ContainerLeftSegActionContent">
        <div class="ContainerLeftSegActionContentTitle">
          <div class="picture"></div>
          <p class="title">分解动作</p>
        </div>
        <div class="ContainerLeftSegActionContentValue">
          <div class="subActionPull">
            <p>拉</p>
          </div>
          <div class="subActionCite">
            <p>引</p>
          </div>
          <div class="subActionFling">
            <p>投</p>
          </div>
          <div class="subActionHunk">
            <p>蹲</p>
          </div>
        </div>
        <!-- 存放分解动作; -->
      </div>
      <div class="Interval">
        <div class="chunk"></div>
        <div class="line"></div>
        <div class="chunk"></div>
      </div>
    </div>
    <div class="ContainerLeftNodeAction">
      <div class="Interval">
        <div class="chunk"></div>
        <div class="line"></div>
        <div class="chunk"></div>
      </div>
      <div class="ContainerLeftNodeActionContent">
        <div class="ContainerLeftNodeActionContentTitle">
          <div class="picture"></div>
          <p class="title">骨架节点</p>
        </div>
        <div class="ContainerLeftNodeActionContentValue">
          <liveStream v-if="WidthHandleLoad" :myVideoId="myTestVideo2"
            :videoUrl="nodeVideoUrl" :componentWidth="nodeComponentWidth">
          </liveStream>
        </div>
        <!-- 存放骨架节点; -->
      </div>
      <div class="Interval">
        <div class="chunk"></div>
        <div class="line"></div>
        <div class="chunk"></div>
      </div>
    </div>
  </div>
</template>
    
    
    
<script lang="js">
// import PageHeader from '../../layouts/header/index.vue';
import liveStream from '../../../../../components/liveStream/index.vue'
export default {
  name: 'shootReviewLeft',
  props: {
    cWidthAndHeightComputed: {
      type: Object,
      default: () => ({width:10,height:10}),
    },
  },
  components: {
    liveStream,
  },
  data() {
    return {
      standardVideoUrl: "http://10.112.147.7:7878/standard.mp4 " ,//"http://10.109.252.160:8000/standard.mp4", //
      nodeVideoUrl: "http://10.112.147.7:7878/standard_unbackground.mp4 ", //"http://10.109.252.160:8000/standard_unbackground.mp4",//
      WidthHandleLoad: true,
      myTestVideo1: "myTestVideo1",
      myTestVideo2: "myTestVideo2",
      standardComponentWidth: 10 + "px",//((document.body.clientWidth > 1500 ? document.body.clientWidth : 1500) * 0.2 - 40)
      nodeComponentWidth: 10 + "px",//((document.body.clientWidth > 1500 ? document.body.clientWidth : 1500) * 0.2 - 40)
    }
  },
  mounted() {
    //console.log("Left start！！！");
  },
  watch: {
    cWidthAndHeightComputed: { // 监听页面宽度或者高度
      handler: function (val,oldval) {
        //console.log("cWidthAndHeightComputedLeft",val,oldval)
        if(oldval !== undefined && val.height === oldval.height && val.width == oldval.width){
          return
        }
        //console.log("左边组件新的宽和高为：", val)
        this.WidthHandleLoad = false;
        let widthValue = 0;
        if (val.width > 1500) {
          widthValue = ((val.width) * 0.2 - 40) / 16;
          widthValue = ((val.width) * 0.2 - 40) / 16;
        }
        else {
          widthValue = ((1500) * 0.2 - 40) / 16;
          widthValue = ((1500) * 0.2 - 40) / 16;
        }
        let heightValue = 0;
        if (val.height > 750) {
          heightValue = ((val.height - 50) * 0.3 - 60) / 9;
          heightValue = ((val.height - 50) * 0.3 - 60) / 9;
        }
        else {
          heightValue = ((750 - 50) * 0.3 - 60) / 9;
          heightValue = ((750 - 50) * 0.3 - 60) / 9;
        }
        this.standardComponentWidth = parseInt(widthValue > heightValue ? heightValue * 16 : widthValue * 16) + 'px';
        this.nodeComponentWidth = parseInt(widthValue > heightValue ? heightValue * 16 : widthValue * 16) + 'px';
        this.$nextTick(() => {
          // 在 DOM 中添加 my-component 组件
          this.WidthHandleLoad = true;
        });
      },
      immediate: true,
      deep:true,
    },
  },
  methods: {

  }
}
</script>
    
<style lang="scss" scoped>
@import './index.scss';
</style>